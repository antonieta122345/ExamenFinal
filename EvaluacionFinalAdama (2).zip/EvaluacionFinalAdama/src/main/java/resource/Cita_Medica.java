package resource;

import lombok.extern.slf4j.Slf4j;
import model.TradeCitasMedicas;
import model.TradePacientes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RequestMapping("/api" )
@RestController
public class Cita_Medica {

    @GetMapping("/")
    public String get_saludo() {
        return "Hola Mundo";
    }

    @PostMapping("/")
    public ResponseEntity doTrade(@RequestBody_ TradeCitasMedicas tradeCitasMedicas) {
        log.info("nueva peticion de trade: {}", tradeCitasMedicas);
        new ResponseEntity<>(HttpStatus.CREATED);
    }

}
