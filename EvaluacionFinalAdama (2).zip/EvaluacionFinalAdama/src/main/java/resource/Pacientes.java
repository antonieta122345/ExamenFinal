package resource;

import model.TradeDoctores;
import model.TradePacientes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

public class Pacientes {
    @GetMapping("/")
    public String get_saludo() {
        return "Hola Mundo";
    }

    @PostMapping("/")
    public ResponseEntity doTrade(@RequestBody_ TradePacientes tradePacientes) {
        log.info("nueva peticion de trade: {}", TradePacientes);
        new ResponseEntity<>(HttpStatus.CREATED);
    }
}
