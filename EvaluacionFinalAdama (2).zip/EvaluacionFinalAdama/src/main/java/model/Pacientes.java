package model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Pacientes {
    private String firstName;
    private String lastName;
    private String email;
    private double weight;
    private double height;
    private String personalDisease;
    private String bloodType;

}
