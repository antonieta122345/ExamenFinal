package model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class TradeDoctores {
    private TradeDoctores owner;

    private TradeDoctores borrowed;
}
