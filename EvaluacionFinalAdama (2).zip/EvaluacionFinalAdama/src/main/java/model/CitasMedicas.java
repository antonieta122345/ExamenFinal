package model;

public class CitasMedicas {
    private String doctorId;
    private String disease;
    private String detail;
    private String dateOfAppointment;
    private String timeOfAppointment;
    private String patientId;
}
