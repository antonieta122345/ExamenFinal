package com.example.EvaluacionFinalAdama;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvaluacionFinalAdamaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvaluacionFinalAdamaApplication.class, args);
	}

}
