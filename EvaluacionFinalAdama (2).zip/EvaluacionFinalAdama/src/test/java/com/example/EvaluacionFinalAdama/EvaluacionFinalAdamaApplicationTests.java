package com.example.EvaluacionFinalAdama;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvaluacionFinalAdamaApplicationTests {

	@Test
	void contextLoads() {
	}

}
